package problemStatement_3;

public class Calculator {

    public int operationBinary(int a, int b, IntegerMath op) {
        return op.operation(a, b);
    }
}
