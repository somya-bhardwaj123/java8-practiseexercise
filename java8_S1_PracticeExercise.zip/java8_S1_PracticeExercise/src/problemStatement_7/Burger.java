package problemStatement_7;

public interface Burger {
	String makeBurger();

}

